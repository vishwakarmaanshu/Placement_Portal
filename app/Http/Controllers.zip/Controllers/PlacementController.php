<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Placement;
use App\Models\Course;
use App\Models\User;
use Illuminate\Support\Facades\Auth;


class PlacementController extends Controller
{
    // Show all placements
    public function index()
    {
        $placements = Placement::with(['user', 'course'])->get();
        return view('admin.placements.index', compact('placements'));
    }

    // Show create form
   public function create()
{
    $users = User::all(); // ✅ add this line
    $courses = Course::all();
    return view('admin.placements.create', compact('users', 'courses'));
}

    // Store placement
    public function store(Request $request)
    {
        $data = $request->validate([
            'user_identifier' => 'required',
            'course_id' => 'required|exists:courses,id',
            'company' => 'required',
            'photo' => 'nullable|image|max:2048',
        ]);

        // Find user by first_name or email
        $user = User::where('first_name', $data['user_identifier'])
                    ->orWhere('email', $data['user_identifier'])
                    ->first();

        if (!$user) {
            return back()->with('error', 'Invalid user. No user found with that name or email.');
        }

        $placementData = [
            'user_id' => $user->id,
            'course_id' => $data['course_id'],
            'company' => $data['company'],
        ];

        if ($request->hasFile('photo')) {
            $placementData['photo'] = $request->file('photo')->store('photos', 'public');
        }
// dd($placementData);

        Placement::create($placementData);

        return redirect()->route('admin.placements.index')->with('success', 'Placement added successfully!');
    }

    // Edit placement form
    public function edit($id)
    {
        $placement = Placement::findOrFail($id);
        $courses = Course::all();
        return view('admin.placements.edit', compact('placement', 'courses'));
    }

    // Update placement
    public function update(Request $request, $id)
    {
        $placement = Placement::findOrFail($id);

        $data = $request->validate([
            'course_id' => 'required|exists:courses,id',
            'company' => 'required',
            'photo' => 'nullable|image|max:2048',
        ]);

        if ($request->hasFile('photo')) {
            $data['photo'] = $request->file('photo')->store('photos', 'public');
        }

        $placement->update($data);

        return redirect()->route('admin.placements.index')->with('success', 'Placement updated!');
    }

    // Delete placement
    public function destroy($id)
    {
        $placement = Placement::findOrFail($id);
        $placement->delete();
        return redirect()->route('admin.placements.index')->with('success', 'Placement deleted!');
    }

    // Admin dashboard
    public function adminDashboard()
    {
        $placements = Placement::with(['user', 'course'])->get();
        return view('admin.dashboard', compact('placements'));
    }

    // Homepage
    public function home()
    {
        $placements = Placement::latest()->take(10)->with(['user', 'course'])->get();
        return view('home', compact('placements'));
    }
    public function showLogin()
{
    return view('auth.login'); // or wherever your login blade is
}

public function loginUser(Request $request)
{
    $credentials = $request->only('email', 'password');

    if (Auth::attempt($credentials)) {
        return redirect()->intended('user/dashboard'); // or your route
    }

    return back()->withErrors(['email' => 'Invalid credentials.']);
}

public function showRegister()
{
    return view('auth.register'); // make sure this Blade view exists
}


    public function registerUser(Request $request)
    {
        $request->validate([
            'first_name' => 'required',
            'email' => 'required|email|unique:users',
            'password' => 'required|confirmed|min:6'
        ]);

        User::create([
            'first_name' => $request->first_name,
            'email' => $request->email,
            'password' => Hash::make($request->password),
        ]);

        return redirect()->route('login')->with('success', 'Registration successful!');
    }

    public function dashboard()
{
    $user = auth()->user();
    return view('user.dashboard', compact('user'));
}


}
