<?php

namespace App\Http\Controllers;

use App\Models\Course;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\Auth;

use App\Models\User;


class CourseController extends Controller
{
    public function index()
    {
        $courses = Course::all();
        return view('admin.courses.index', compact('courses'));
    }

    public function create()
    {
        return view('admin.courses.create');
    }

    public function store(Request $request)
    {
        $request->validate([
            'name' => 'required|string',
            'duration' => 'required|string',
            'technologies' => 'nullable|string',
            'image' => 'nullable|image',
            'youtube_links' => 'nullable|array',
        ]);

        $imagePath = null;
        if ($request->hasFile('image')) {
            $imagePath = $request->file('image')->store('course_images', 'public');
        }

        Course::create([
            'name' => $request->name,
            'duration' => $request->duration,
            'technologies' => $request->technologies,
            'image' => $imagePath,
            'youtube_links' => json_encode($request->youtube_links),
        ]);

        return redirect()->route('admin.courses.index')->with('success', 'Course added successfully');
    }

    public function edit(Course $course)
    {
        return view('admin.courses.edit', compact('course'));
    }

    public function update(Request $request, Course $course)
    {
        $request->validate([
            'name' => 'required|string',
            'duration' => 'required|string',
            'technologies' => 'nullable|string',
            'image' => 'nullable|image',
            'youtube_links' => 'nullable|array',
        ]);

        if ($request->hasFile('image')) {
            if ($course->image) {
                Storage::disk('public')->delete($course->image);
            }
            $course->image = $request->file('image')->store('course_images', 'public');
        }

        $course->update([
            'name' => $request->name,
            'duration' => $request->duration,
            'technologies' => $request->technologies,
            'youtube_links' => json_encode($request->youtube_links),
        ]);

        return redirect()->route('admin.courses.index')->with('success', 'Course updated successfully');
    }

    public function destroy(Course $course)
    {
        if ($course->image) {
            Storage::disk('public')->delete($course->image);
        }
        $course->delete();
        return redirect()->route('admin.courses.index')->with('success', 'Course deleted successfully');
    }

   public function showCourses()
{
    $courses = Course::all();
    $user = Auth::user();

    // get enrolled course_ids
    $enrolledCourseIds = $user->courseEnrollments->pluck('course_id')->toArray();

    return view('user.courses', compact('courses', 'enrolledCourseIds', 'user'));
}

public function enroll(Request $request)
{
    $request->validate([
        'course_id' => 'required|exists:courses,id',
    ]);

    $user = Auth::user();

    $exists = CourseEnrollment::where('user_id', $user->id)
        ->where('course_id', $request->course_id)
        ->exists();

    if ($exists) {
        return response()->json(['success' => false, 'message' => 'Already enrolled.']);
    }

    CourseEnrollment::create([
        'user_id' => $user->id,
        'course_id' => $request->course_id,
    ]);

    return response()->json(['success' => true]);
}
}
